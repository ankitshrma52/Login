=== Simple Registration Form ===
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=amu02.aftab@gmail.com&item_name=Simple+Simple+Registration+Form
Tags: registration form ,simple registration form
Contributors: amu02aftab
Author: amu02aftab
Tested up to: 4.4.2
License: GPLv2
Requires at least: 3.5.0
Stable tag: 1.0

== Description ==
This plugin allows users to put simple registration form on page , post or template using shortcode 
 
`
[simple-registration-form]
`

== Screenshots ==

1. Front end registration form

== Frequently Asked Questions ==
1. No technical skills needed.

== Changelog ==

= 1.0.1 =
* Bug fixes
* Update readme.txt

= 1.0.0 =
* Initial release

== Upgrade Notice == 
This is first version no known notices yet

== Installation ==
1. Upload the folder "simple-registration-form" to "/wp-content/plugins/"
2. Activate the plugin through the "Plugins" menu in WordPress
3. For registration form use below shortcode  
`
[simple-registration-form]
`



