<?php 
	/*
		Template Name:Login	
	*/
	
	get_header();
		
			echo do_shortcode("[simple-login-form]");			
	
	get_footer();
	
	
	
	
	

?>

