<?php 
/*
Template Name: Regis_Log
*/
//require_once('simple');

//Echo "<a href=/"do_shortcode("[simple-registration-form]")/";>Registration</a>";

get_header();
	
	echo do_shortcode("[simple-registration-form]");

get_footer();
?>
